<?php

$config = array(

    //应用ID,您的APPID。
    'app_id' => '2018041602569588',

    //商户私钥，您的原始格式RSA私钥
    'merchant_private_key' => 'MIIEpAIBAAKCAQEAsLZ9mTrgul/x/5lgzmyqzD5dQIocsjwt2Y1aXc8I11iCkVfZEAvyDmc6MLKXuTnRZciSamIyTOlEik/RYHEJuh25rXLW2mkrtMZI8XpVe2fBrPQMLKODH6L4/XYJ7Fyf+XszuRkbkveNr+7ujvIOy8TuZt23ctXDgNPxyQfUKh04yro19mE69xxSauvA5uK+Kltfm+SfUKmxZ3slsJ2f7s6Iyzh+co0DcJbIDI9lF8zcSSYQNHoRuid/+P9Fy90hh0Q++5e58nQJHe+n8BMPji/u0q1SHtgQKK70CBs9hbRsotYCGhKHLgqtIEm1MBO9zbLtFEVDcNUdQM+cY2uzQQIDAQABAoIBAQCN3sTxKwLWvkakBPhiYX2yIfNt6DPnqEbLHR/Kpnebo9SXaWa76ks34wolpIwIyfFh/OgHfrSRaMl9HV2kRrwfbtPt+3+gs8TCClrve157h65G81t+zvtrf8TUgFqxJx/MBGxfE1g+4n4fG/zsSEs2rvETJrer+xBNMlswIRflgmC1fzyKq1KXfHcyeasmN7eClxItqQsm7mE6zKQxrC9oT3SD+tfnEnBh0vZmoFQv9+TOWct1iOeJhtJfANkRpmzY8vIasLL8UT5VrkzjOOAN2A1YRFziE8G72ogknWgX7qjurHYp6yTAeQPB4jSHzbSanp+NiYYuf7xC1KW4gW6dAoGBANsfw2mdLG7pdF7KC2WEuDCrje1jL5rJehjS54aIkutA5h6E3STbZKINBZOHYI1Ma331myGVYpKm25s3WGnCfAuxrCtQF8Wp8xUYcAHj1Jcix4iDT09U0xXGA+jE53dsz1DEFIFPGrJsPoqy1+wJLeK/ta00P5a8GuvA0Y2atkXvAoGBAM5zlHhymt/rlRvn1MOkhKTtHazRhI7SO/Ll/MQR1qsj9gFi7O1hpRssU79ddktQusdRh8K+Et+wK1HABpBu/lT/M0IEEWzty2NIL/kG5eCfBVdiyXhmyeWWUIGU8gR+/VhBMESKhcoadpAwhzdmZtMKHru3ejDfiOCjDcuJaEnPAoGBAIIPOVqPmtb+JD8650bLXtQsj2IudAwIuDrRu/BjUejmrW/B5szAl9uDpSKqwMk9abPqurhVRZvMBB7927FyaVQ7kfhnYqTFOe30gk7s3rsSPqKtZb6tl1ieHqXjcYu1/ttudslFnY/3pauHeZe03xJuPbRfhbq/Ta9O1FKbWMLrAoGAR4SUh1E0Q6PJqLwb4ZZpePTHVenS4OMFb3SqpoWDdw/jFcHeT7GGz64AaQeIhji2K3wb6qOLyD+wEgbSf1Bj/K/XYuQj4TdTQNZt//eaxMBxyj7nijUZddYnl2wwlswjGWKjxOqzxDp8niChhtiLgEo+MUszIiEduqvhiIPWQ9MCgYAA5t7ZExLAOwr2sTNHFos0RHwsk02X0A1g2E1ear2sswKJzSA5sy13VcXjGbYMNzSwM33Oq/g0Q0+qrnAuDu5oUvWhUcGKbkjSO+YlBN6iOIB0aJb+Jzb7NkyYKVQp0C6hu6qZSlB0l9m7gwpGX8dhgZpBVAPTak1mJfI4DqyjEA==',

    //编码格式
    'charset' => 'UTF-8',

    //json
    'format' => 'json',

    //签名方式
    'sign_type' => 'RSA2',

    //支付宝网关
    'gatewayUrl' => 'https://openapi.alipay.com/gateway.do',

    //支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    'alipay_public_key' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiTsz1A6O31BgDVZPNxW2JEUwe8DljOG7SVeB7tYNHj8S49zwJFhmTQIaMn35Pd1xxV+rdPwJGX3To3RLjW/Nx40vMABqJ4YQC/m/+wUJITreH/5GbacLfxZrxup4c+5Or2xsoI3NmN1FZM+IsqZVhutVPTXWrkJrnZjGBY0Re8NNJnUx3mbGYwaQ9p0DU4fOM8Oy4yjrvxTOZTGCk0+1Hk53YZeWXwxcWN0JuuW0G+hwLDxi6iqX2KHixleMGi1Q7pm8At02pIQsa6fa9H6eB2l3tYTpGP5kLuVHFjEXNquu+nh5W/OHf3bw6QZWKsYDs7aYKPGgVqxa5Hfaqt/aFQIDAQAB',

);

